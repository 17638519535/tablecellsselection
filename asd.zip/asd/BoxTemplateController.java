package com.jtech.toa.controller.box;

import com.jtech.toa.controller.index.BaseController;
import com.jtech.toa.project.model.dto.ShiroUser;
import com.jtech.toa.project.model.dto.boxtemplate.TemplateFormMap;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.List;

/**
 * @author mayongfu
 * @ClassName : BoxTemplateController
 * @Description:
 * @date 2020/4/13   13:34
 */
@Controller
@RequestMapping("/ths")
public class BoxTemplateController extends BaseController {

    @RequestMapping("/box")
    public String findData(Model model) {
        final Subject subject = SecurityUtils.getSubject();
        final ShiroUser shiroUser = (ShiroUser) subject.getPrincipal();
        //  TemplateFormMap templateFormMap =getFormMap(TemplateFormMap.class);
        TemplateFormMap templateFormMap = new TemplateFormMap();
        templateFormMap.put("where", "where 1=1 and laboratory_data_detail_id=111");
        List<TemplateFormMap> mapList = commonService.findByWhere(templateFormMap);
        model.addAttribute("mapList", mapList);
        //json 数据
        return "/hts/htsList";
    }

   private void jsonTest(){
       JSONObject object=new JSONObject();
       object.append("id",1);
       String json = object.toString();


 System.out.println(object.toString());


   }
}