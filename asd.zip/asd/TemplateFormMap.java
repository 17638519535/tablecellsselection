package com.jtech.toa.project.model.dto.boxtemplate;

import com.jtech.toa.project.annotation.TableSeg;
import com.jtech.toa.project.common.FormMap;

import java.io.Serializable;

/**
 * @author mayongfu
 * @ClassName : TemplateFormMap
 * @Description:
 * @date 2020/4/13   16:47
 */
@TableSeg(tableName = "t_laboratory_data_detail_hts_detail", id="id")
public class  TemplateFormMap extends FormMap<String, Object> implements Serializable {
    private static final long serialVersionUID = 1L;

}
